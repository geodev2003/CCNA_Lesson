import { PrismaClient } from '@prisma/client';
const g = globalThis as any;
export const prisma: PrismaClient = g._prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query','error'] : ['error'],
});
if (process.env.NODE_ENV !== 'production') g._prisma = prisma;
